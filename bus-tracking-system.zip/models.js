const mongoose = require('mongoose');

// Driver / Conductor Schema
const UserSchema = new mongoose.Schema({
  role: { type: String, enum: ['driver', 'conductor', 'admin'], required: true },
  userId: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  name: String,
  isLoggedIn: { type: Boolean, default: false },
  lastLogin: Date,
  lastLogout: Date
});

// Active Bus Route & Location Schema
const BusSessionSchema = new mongoose.Schema({
  busNumber: { type: String, required: true },
  driverId: String,
  conductorId: String,
  district: { type: String, required: true },
  fromLocation: { type: String, required: true },
  toLocation: { type: String, required: true },
  fareAmount: { type: Number, required: true },
  isLive: { type: Boolean, default: false },
  currentLocation: {
    lat: Number,
    lng: Number,
    updatedAt: Date
  }
});

// Viewer Search Analytics Schema (For Admin)
const SearchLogSchema = new mongoose.Schema({
  viewerIp: String,
  district: String,
  searchedRoute: String,
  selectedBusNumber: String,
  timestamp: { type: Date, default: Date.now }
});

module.exports = {
  User: mongoose.model('User', UserSchema),
  BusSession: mongoose.model('BusSession', BusSessionSchema),
  SearchLog: mongoose.model('SearchLog', SearchLogSchema)
};
