# Bus Live Tracking System

A full-stack web application for real-time bus location tracking based on driver/conductor GPS.

## Setup Instructions

1. **Prerequisites:**
   - Install Node.js (v16+)
   - Install MongoDB locally OR prepare a MongoDB Atlas connection string.

2. **Installation:**
   Extract the zip file, open terminal/command prompt in the directory and run:
   ```bash
   npm install
   ```

3. **Running the App:**
   - Make sure MongoDB is running locally on port `27017` (or set `MONGO_URI` environment variable).
   - Start the server:
     ```bash
     npm start
     ```
   - Open browser at `http://localhost:3000`

## Features
- **Viewer:** Search buses by district and route. Tracks live location on OpenStreetMap via WebSocket.
- **Driver/Conductor Dashboard:** Login, enter bus route details, and toggle GPS sharing.
- **Admin Dashboard:** Monitor driver login/logout status and view viewer search history logged in the database.
