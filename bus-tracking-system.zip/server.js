const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const mongoose = require('mongoose');
const { User, BusSession, SearchLog } = require('./models');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(express.json());
app.use(express.static('public'));

// Connect DB (Change URL if using MongoDB Atlas)
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/bustracker';
mongoose.connect(MONGO_URI)
  .then(() => console.log('MongoDB Connected Successfully'))
  .catch(err => console.error('MongoDB Connection Error:', err));

// --- REST API ENDPOINTS ---

// Driver / Conductor Login
app.post('/api/login', async (req, res) => {
  try {
    const { userId, password, role } = req.body;
    let user = await User.findOne({ userId, role });
    
    // Auto-create dummy account if running for first time
    if (!user) {
      user = await User.create({ userId, password, role, isLoggedIn: true, lastLogin: new Date() });
    } else {
      if (user.password !== password) {
        return res.status(401).json({ error: 'Invalid password' });
      }
      user.isLoggedIn = true;
      user.lastLogin = new Date();
      await user.save();
    }

    res.json({ success: true, userId: user.userId, role: user.role });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Driver / Conductor Logout
app.post('/api/logout', async (req, res) => {
  try {
    const { userId } = req.body;
    await User.findOneAndUpdate({ userId }, { isLoggedIn: false, lastLogout: new Date() });
    await BusSession.findOneAndUpdate({ $or: [{ driverId: userId }, { conductorId: userId }] }, { isLive: false });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Start Bus Session (Driver inputs trip info)
app.post('/api/bus/start', async (req, res) => {
  try {
    const { busNumber, driverId, district, fromLocation, toLocation, fareAmount } = req.body;
    
    const bus = await BusSession.findOneAndUpdate(
      { busNumber },
      { busNumber, driverId, district: district.toLowerCase(), fromLocation, toLocation, fareAmount, isLive: true },
      { upsert: true, new: true }
    );

    res.json({ success: true, bus });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Search Buses by District and Route (Viewer Feature)
app.post('/api/viewer/search', async (req, res) => {
  try {
    const { district, routeQuery, viewerIp } = req.body;

    // Log Search to Database for Admin
    await SearchLog.create({
      viewerIp: viewerIp || req.ip,
      district,
      searchedRoute: routeQuery
    });

    // Query matching buses currently LIVE in that district
    const query = { district: district.toLowerCase(), isLive: true };
    if (routeQuery) {
      query.$or = [
        { fromLocation: new RegExp(routeQuery, 'i') },
        { toLocation: new RegExp(routeQuery, 'i') }
      ];
    }

    const buses = await BusSession.find(query);
    res.json(buses);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Admin API: View logs and Active Drivers/Conductors
app.get('/api/admin/dashboard', async (req, res) => {
  try {
    const activeStaff = await User.find({ role: { $ne: 'admin' } }, 'userId role isLoggedIn lastLogin lastLogout');
    const searchLogs = await SearchLog.find().sort({ timestamp: -1 }).limit(100);
    res.json({ activeStaff, searchLogs });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --- REAL-TIME WEBSOCKET HANDLING ---
io.on('connection', (socket) => {
  socket.on('updateLocation', async (data) => {
    const { busNumber, lat, lng } = data;
    
    await BusSession.findOneAndUpdate(
      { busNumber },
      { currentLocation: { lat, lng, updatedAt: new Date() } }
    );

    // Broadcast location update to viewers tracking this bus
    io.emit(`busLocation:${busNumber}`, { busNumber, lat, lng });
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
